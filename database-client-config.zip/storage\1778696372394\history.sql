/* 2026-05-13 16:10:38 [1184 ms] */ 
CREATE DATABASE ecommerce;
/* 2026-05-13 16:11:16 [404 ms] */ 
USE ecommerce;
/* 2026-05-13 16:11:23 [873 ms] */ 
CREATE TABLE categoria (
    id INT AUTO_INCREMENT,
    nome VARCHAR(100),
    descricao TEXT,
    PRIMARY KEY (id)
);
/* 2026-05-13 16:12:09 [222 ms] */ 
CREATE TABLE produto (
    id INT AUTO_INCREMENT,
    nome VARCHAR(150),
    descricao TEXT,
    preco DECIMAL(10,2),
    estoque INT,
    categoria_id INT,
    PRIMARY KEY (id),
    FOREIGN KEY (categoria_id) REFERENCES categoria(id)
);
/* 2026-05-13 16:15:09 [238 ms] */ 
INSERT INTO categoria (nome, descricao) VALUES
('Eletrônicos', 'Produtos eletrônicos e acessórios'),
('Roupas', 'Vestuário masculino e feminino'),
('Livros', 'Livros de diversos gêneros'),
('Casa e Decoração', 'Itens para casa e decoração'),
('Esportes', 'Artigos esportivos e acessórios');
/* 2026-05-13 16:15:12 [210 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES
('Smartphone Galaxy S23', 'Smartphone Samsung com 256GB', 3999.90, 15, 1),
('Notebook Dell Inspiron', 'Notebook Dell i7 16GB RAM', 5299.00, 8, 1),
('Fone Bluetooth JBL', 'Fone sem fio com cancelamento de ruído', 499.90, 30, 1),

('Camiseta Básica', 'Camiseta de algodão unissex', 59.90, 50, 2),
('Calça Jeans Slim', 'Calça jeans masculina slim fit', 129.90, 25, 2),
('Jaqueta Feminina', 'Jaqueta feminina impermeável', 249.90, 12, 2),

('Dom Casmurro', 'Livro clássico de Machado de Assis', 39.90, 20, 3),
('Clean Code', 'Livro sobre boas práticas de programação', 89.90, 10, 3),
('O Senhor dos Anéis', 'Trilogia de fantasia épica', 119.90, 7, 3),

('Luminária LED', 'Luminária moderna para escritório', 79.90, 18, 4),
('Tapete Decorativo', 'Tapete para sala 2x3m', 199.90, 6, 4),

('Bola de Futebol', 'Bola oficial tamanho 5', 99.90, 14, 5),
('Tênis de Corrida', 'Tênis esportivo leve e confortável', 299.90, 9, 5),
('Garrafa Térmica', 'Garrafa térmica inox 1L', 69.90, 22, 5);
/* 2026-05-13 16:39:20 [213 ms] */ 
USE ecommerce;
/* 2026-05-13 16:39:57 [205 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 16:41:11 [233 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE ID = 2;
/* 2026-05-13 16:42:13 [222 ms] */ 
UPDATE produto
SET categoria_id=3
-- WHERE ID = 2;
/* 2026-05-13 16:51:36 [3025 ms] */ 
USE ecommerce;
/* 2026-05-13 16:51:41 [203 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE ID = 3;
/* 2026-05-13 16:51:43 [203 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE ID = 2;
/* 2026-05-13 16:51:50 [209 ms] */ 
UPDATE produto
SET categoria_id=4
WHERE ID = 3;
/* 2026-05-13 16:51:55 [203 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE ID = 4;
/* 2026-05-13 16:52:02 [202 ms] */ 
UPDATE produto
SET categoria_id=1
WHERE ID = 5;
/* 2026-05-13 16:53:20 [203 ms] */ 
USE ecommerce;
/* 2026-05-13 16:53:30 [638 ms] */ 
UPDATE produto
SET categoria_id=1
WHERE ID = 1;
/* 2026-05-13 16:53:38 [864 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE ID = 2;
/* 2026-05-13 16:53:47 [204 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE ID = 3;
/* 2026-05-13 16:53:52 [633 ms] */ 
UPDATE produto
SET categoria_id=4
WHERE ID = 3;
/* 2026-05-13 16:53:58 [202 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE ID = 4;
/* 2026-05-13 16:55:32 [204 ms] */ 
USE ecommerce;
/* 2026-05-13 16:55:35 [202 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'M%';
/* 2026-05-13 16:56:46 [203 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 16:56:50 [203 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'S%';
/* 2026-05-13 16:56:56 [204 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:57:08 [204 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'B%';
/* 2026-05-13 16:57:10 [203 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:57:33 [650 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE nome LIKE'%';
/* 2026-05-13 16:57:36 [653 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:57:46 [203 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE nome LIKE'B%';
/* 2026-05-13 16:57:50 [648 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE ID = 2;
/* 2026-05-13 16:58:11 [203 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE id = 3;
/* 2026-05-13 16:58:28 [202 ms] */ 
USE ecommerce;
/* 2026-05-13 16:58:31 [203 ms] */ 
UPDATE produto
SET categoria_id=4
WHERE id = 4;
/* 2026-05-13 16:58:36 [204 ms] */ 
UPDATE produto
SET categoria_id=1
WHERE id = 4;
/* 2026-05-13 16:58:41 [203 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE id = 1;
/* 2026-05-13 16:58:44 [203 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:58:55 [1104 ms] */ 
UPDATE produto
SET categoria_id=4
WHERE id = 2;
/* 2026-05-13 17:00:11 [934 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE preco >=500;
/* 2026-05-13 17:00:23 [202 ms] */ 
USE ecommerce;
/* 2026-05-13 17:01:05 [204 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES
('Smartphone Galaxy S23', 'Smartphone Samsung com 256GB', 3999.90, 15, 1),
('Notebook Dell Inspiron', 'Notebook Dell i7 16GB RAM', 5299.00, 8, 1),
('Fone Bluetooth JBL', 'Fone sem fio com cancelamento de ruído', 499.90, 30, 1),

('Camiseta Básica', 'Camiseta de algodão unissex', 59.90, 50, 2),
('Calça Jeans Slim', 'Calça jeans masculina slim fit', 129.90, 25, 2),
('Jaqueta Feminina', 'Jaqueta feminina impermeável', 249.90, 12, 2),

('Dom Casmurro', 'Livro clássico de Machado de Assis', 39.90, 20, 3),
('Clean Code', 'Livro sobre boas práticas de programação', 89.90, 10, 3),
('O Senhor dos Anéis', 'Trilogia de fantasia épica', 119.90, 7, 3),

('Luminária LED', 'Luminária moderna para escritório', 79.90, 18, 4),
('Tapete Decorativo', 'Tapete para sala 2x3m', 199.90, 6, 4),

('Bola de Futebol', 'Bola oficial tamanho 5', 99.90, 14, 5),
('Tênis de Corrida', 'Tênis esportivo leve e confortável', 299.90, 9, 5),
('Garrafa Térmica', 'Garrafa térmica inox 1L', 69.90, 22, 5);
/* 2026-05-13 17:01:33 [203 ms] */ 
DELETE FROM `produto` WHERE `id` IN (14,13,12,11,10,9,8,7,6,5,4,3,2,1);
/* 2026-05-13 17:01:46 [202 ms] */ 
DELETE FROM `produto` WHERE `id` IN (15,16,17,18,19,20,21,22,23,24,25,26,27,28);
/* 2026-05-13 17:01:57 [202 ms] */ 
USE ecommerce;
/* 2026-05-13 17:02:01 [642 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES
('Smartphone Galaxy S23', 'Smartphone Samsung com 256GB', 3999.90, 15, 1),
('Notebook Dell Inspiron', 'Notebook Dell i7 16GB RAM', 5299.00, 8, 1),
('Fone Bluetooth JBL', 'Fone sem fio com cancelamento de ruído', 499.90, 30, 1),

('Camiseta Básica', 'Camiseta de algodão unissex', 59.90, 50, 2),
('Calça Jeans Slim', 'Calça jeans masculina slim fit', 129.90, 25, 2),
('Jaqueta Feminina', 'Jaqueta feminina impermeável', 249.90, 12, 2),

('Dom Casmurro', 'Livro clássico de Machado de Assis', 39.90, 20, 3),
('Clean Code', 'Livro sobre boas práticas de programação', 89.90, 10, 3),
('O Senhor dos Anéis', 'Trilogia de fantasia épica', 119.90, 7, 3),

('Luminária LED', 'Luminária moderna para escritório', 79.90, 18, 4),
('Tapete Decorativo', 'Tapete para sala 2x3m', 199.90, 6, 4),

('Bola de Futebol', 'Bola oficial tamanho 5', 99.90, 14, 5),
('Tênis de Corrida', 'Tênis esportivo leve e confortável', 299.90, 9, 5),
('Garrafa Térmica', 'Garrafa térmica inox 1L', 69.90, 22, 5);
/* 2026-05-13 17:02:21 [640 ms] */ 
USE ecommerce;
/* 2026-05-13 17:02:23 [203 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE preco >=500;
/* 2026-05-13 17:02:56 [203 ms] */ 
UPDATE produto
SET categoria_id = 30
WHERE id = 1;
/* 2026-05-13 17:03:48 [204 ms] */ 
UPDATE produto
SET categoria_id = 20
WHERE id = 1;
/* 2026-05-13 17:04:04 [846 ms] */ 
USE ecommerce;
/* 2026-05-13 17:09:22 [208 ms] */ 
UPDATE produto
SET
    nome = 'pc usado - notebook',
    descricao = 'Notebook com SSD e 16GB de RAM',
    estoque = 15,
    categoria_id = 1
WHERE id=4;
/* 2026-05-13 17:09:31 [207 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 17:09:47 [207 ms] */ 
UPDATE produto
SET
    nome = 'pc usado - notebook',
    descricao = 'Notebook com SSD e 16GB de RAM',
    estoque = 15,
    categoria_id = 1
WHERE id=35;
/* 2026-05-13 17:09:49 [206 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:17:43 [544 ms] */ 
DELETE FROM produto WHERE id =33;
/* 2026-05-13 18:17:46 [203 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:21:10 [269 ms] */ 
INSERT INTO produto() 
VALUES(DEFAULT, 'telefoneX','telefone legal',50.00,120,1);
/* 2026-05-13 18:21:13 [203 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:28:59 [697 ms] */ 
DELETE FROM produto
WHERE nome = 'Clean Code'AND id=36;
/* 2026-05-13 18:29:03 [204 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:30:20 [663 ms] */ 
DELETE FROM produto
WHERE nome = 'Clean Code' or id=31;
/* 2026-05-13 18:30:26 [202 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:36:30 [2166 ms] */ 
CREATE DATABASE estoquecomercial;
/* 2026-05-13 18:38:17 [333 ms] */ 
CREATE TABLE ItensEstoque(
idItem INT NOT NULL AUTO_INCREMENT,
descricaoItem VARCHAR(200),
setorItem VARCHAR(200),
precoVendaItem DOUBLE(9,2),
estoqueItem INT,
PRIMARY KEY (idItem)
);
/* 2026-05-13 18:38:37 [658 ms] */ 
INSERT INTO ItensEstoque
(descricaoItem,setorItem,precoVendaItem,estoqueItem)VALUES
('Suco de Laranja','Bebidas','7.50',250),
('Macarrão 1kg','Alimentos','5.20',180),
('Sabão em pó','Limpeza','12.90',90),
('Café Torrado','Alimentos','15.80',120),
('Iogurte Natural','Laticínios','4.30',350),
('Biscoito Integral',NULL,'3.90',210),
('Molho de Tomate','Alimentos','2.80',500);
/* 2026-05-13 18:40:06 [842 ms] */ 
SELECT * FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 18:53:19 [2166 ms] */ 
SELECT * from `ItensEstoque` LIMIT 100;
/* 2026-05-13 18:53:38 [203 ms] */ 
SELECT `setorItem` FROM `ItensEstoque`
WHERE `descricaoItem` = 'Iogurte Natural' LIMIT 100;
/* 2026-05-13 18:56:20 [674 ms] */ 
SELECT descricaoItem, setorItem, precoVendaItem
FROM ItensEstoque
WHERE setorItem<> 'Iogurte Natural' LIMIT 100;
/* 2026-05-13 19:01:45 [202 ms] */ 
SELECT*FROM ItensEstoque
WHERE precoVendaItem=3.90
AND estoqueItem=210;
/* 2026-05-13 19:06:51 [645 ms] */ 
SELECT descricaoItem, setorItem
FROM `ItensEstoque`
WHERE `idItem` = 1 OR `precoVendaItem` >30 LIMIT 100;
/* 2026-05-13 19:07:00 [199 ms] */ 
SELECT descricaoItem, setorItem
FROM `ItensEstoque`
WHERE `idItem` = 1 OR `precoVendaItem` =30 LIMIT 100;
/* 2026-05-13 19:07:10 [202 ms] */ 
SELECT descricaoItem, setorItem
FROM `ItensEstoque`
WHERE `idItem` = 1 OR `precoVendaItem` >30 LIMIT 100;
/* 2026-05-13 19:07:23 [200 ms] */ 
SELECT `descricaoItem`
FROM `ItensEstoque`
WHERE `idItem` = 1 OR `precoVendaItem` > 30 LIMIT 100;
/* 2026-05-13 19:09:59 [200 ms] */ 
SELECT `descricaoItem`
FROM `ItensEstoque`
WHERE NOT `precoVendaItem` = 7.50 LIMIT 100;
/* 2026-05-13 19:16:46 [205 ms] */ 
SELECT descricaoItem FROM ItensEstoque
WHERE precoVendaItem BETWEEN 1.00 AND 7.50 LIMIT 100;
/* 2026-05-13 19:19:19 [201 ms] */ 
SELECT setorItem 
FROM ItensEstoque
WHERE setorItem IN ('Limpeza','Bebidas','Laticínios','CAMABANHO','PRAIA') LIMIT 100;
/* 2026-05-13 19:21:29 [203 ms] */ 
SELECT * from `ItensEstoque` LIMIT 100;
/* 2026-05-13 19:27:02 [204 ms] */ 
SELECT * FROM `ItensEstoque`
WHERE `descricaoItem` LIKE '%ão%' LIMIT 100;
/* 2026-05-13 19:33:28 [432 ms] */ 
SELECT (precoVendaItem * estoqueItem) as total
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 19:34:37 [206 ms] */ 
SELECT (precoVendaItem / estoqueItem) as total
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 19:35:09 [1119 ms] */ 
SELECT (precoVendaItem - estoqueItem) as total
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 19:35:26 [206 ms] */ 
SELECT (precoVendaItem + estoqueItem) as total
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 19:39:34 [207 ms] */ 
SELECT (precoVendaItem * 2) as total
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 19:42:00 [217 ms] */ 
set @nome_produto = 'pc';
/* 2026-05-13 19:42:02 [205 ms] */ 
set @minha_idade = 25;
/* 2026-05-13 19:42:04 [206 ms] */ 
SELECT (precoVendaItem * 2) AS total
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 19:47:08 [2716 ms] */ 
SELECT precoVendaItem
FROM `ItensEstoque`
WHERE `setorItem`
IN ('Alimentos','Limpeza','Praia','Bebidas','Laticinios')
ORDER BY `precoVendaItem` DESC LIMIT 100;
/* 2026-05-13 19:49:19 [209 ms] */ 
SELECT precoVendaItem, `setorItem`
FROM `ItensEstoque`
WHERE `setorItem`
IN ('Alimentos','Limpeza','Praia','Bebidas','Laticinios')
ORDER BY `precoVendaItem`, `setorItem` DESC LIMIT 100;
/* 2026-05-13 20:01:48 [426 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%Molho%' LIMIT 100;
/* 2026-05-13 20:02:27 [680 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%a%' LIMIT 100;
/* 2026-05-13 20:02:39 [210 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%b%' LIMIT 100;
/* 2026-05-13 20:02:42 [206 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%i%' LIMIT 100;
/* 2026-05-13 20:02:47 [664 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%o%' LIMIT 100;
/* 2026-05-13 20:02:51 [206 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%u%' LIMIT 100;
/* 2026-05-13 20:02:56 [1106 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%%' LIMIT 100;
/* 2026-05-13 20:03:04 [206 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%a%' LIMIT 100;
/* 2026-05-13 20:03:12 [206 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%molho%' LIMIT 100;
/* 2026-05-13 20:06:00 [206 ms] */ 
set @nome_produto = 'pc';
/* 2026-05-13 20:06:18 [219 ms] */ 
SELECT AVG(precoVendaItem)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:09:09 [224 ms] */ 
SELECT SUM(estoqueItem)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:11:25 [203 ms] */ 
SELECT MIN (precoVendaItem)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:11:46 [204 ms] */ 
SELECT MAX (precoVendaItem)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:11:48 [205 ms] */ 
SELECT MIN (precoVendaItem)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:11:50 [483 ms] */ 
SELECT MAX (precoVendaItem)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:21:54 [202 ms] */ 
SELECT COUNT (descricaoItem)
from `ItensEstoque`
WHERE `descricaoItem` like '%molho%' LIMIT 100;
/* 2026-05-13 20:21:56 [203 ms] */ 
SELECT precoVendaItem, `setorItem`
FROM `ItensEstoque`
WHERE `setorItem`
IN ('Alimentos','Limpeza','Praia','Bebidas','Laticinios')
ORDER BY `precoVendaItem`, `setorItem` DESC LIMIT 100;
/* 2026-05-13 20:23:12 [643 ms] */ 
SELECT COUNT (estoqueItem)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:23:31 [209 ms] */ 
SELECT SUM (estoqueItem)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:24:28 [217 ms] */ 
SELECT COUNT (estoqueItem)
FROM `ItensEstoque`
WHERE `setorItem` LIMIT 100;
/* 2026-05-13 20:25:29 [203 ms] */ 
SELECT COUNT (`setorItem`)
FROM `ItensEstoque`
WHERE `estoqueItem` LIMIT 100;
/* 2026-05-13 20:25:53 [203 ms] */ 
SELECT SUM(estoqueItem)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:26:26 [203 ms] */ 
SELECT * FROM `ItensEstoque`
WHERE `descricaoItem` LIKE '%ão%' LIMIT 100;
/* 2026-05-13 20:27:51 [202 ms] */ 
SELECT COUNT (`estoqueItem`)
FROM `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:28:57 [204 ms] */ 
SELECT COUNT (`setorItem`)
FROM `ItensEstoque`
WHERE`setorItem` LIMIT 100;
/* 2026-05-13 20:36:20 [1070 ms] */ 
SELECT
    descricaoItem,
    setorItem,
    precoVendaItem
FROM ItensEstoque
WHERE
    setorItem <> 'Iogurte Natural' LIMIT 100;
/* 2026-05-13 20:36:55 [202 ms] */ 
SELECT COUNT (`setorItem`)
FROM `ItensEstoque`
WHERE`setorItem` LIMIT 100;
/* 2026-05-13 20:37:27 [241 ms] */ 
SELECT `setorItem`, COUNT (`setorItem`)
FROM `ItensEstoque`
GROUP BY `setorItem` LIMIT 100;
/* 2026-05-13 20:39:32 [202 ms] */ 
SELECT `setorItem`, AVG (`setorItem`)
FROM `ItensEstoque`
GROUP BY `setorItem` LIMIT 100;
/* 2026-05-13 20:40:09 [653 ms] */ 
SELECT `setorItem`, COUNT (*)
FROM `ItensEstoque`
GROUP BY `setorItem` LIMIT 100;
/* 2026-05-13 20:40:14 [654 ms] */ 
SELECT `setorItem`, COUNT (`setorItem`)
FROM `ItensEstoque`
GROUP BY `setorItem` LIMIT 100;
/* 2026-05-13 20:40:49 [891 ms] */ 
SELECT `setorItem`, AVG (`setorItem`)
FROM `ItensEstoque`
GROUP BY `setorItem` LIMIT 100;
/* 2026-05-13 20:40:50 [202 ms] */ 
SELECT `setorItem`, COUNT (`setorItem`)
FROM `ItensEstoque`
GROUP BY `setorItem` LIMIT 100;
/* 2026-05-13 20:43:29 [690 ms] */ 
SELECT setorItem, AVG (precoVendaItem)
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:44:07 [243 ms] */ 
SELECT setorItem, MIN (precoVendaItem) AND MAX (precoVendaItem)
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:45:08 [667 ms] */ 
SELECT setorItem, MIN (precoVendaItem) AND setorItem, MAX (precoVendaItem)
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:54:14 [202 ms] */ 
SELECT setorItem, AVG (precoVendaItem)
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:54:17 [203 ms] */ 
SELECT setorItem, MIN (precoVendaItem) AND setorItem, MAX (precoVendaItem)
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:55:27 [659 ms] */ 
SELECT setorItem, COUNT (`estoqueItem`)
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:55:41 [943 ms] */ 
SELECT setorItem, COUNT (setorItem)
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:56:14 [200 ms] */ 
SELECT setorItem, COUNT (setorItem)
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:58:26 [653 ms] */ 
SELECT * from `ItensEstoque` LIMIT 100;
/* 2026-05-13 20:59:22 [202 ms] */ 
SELECT estoqueItem, COUNT (estoqueItem)
FROM ItensEstoque
GROUP BY `estoqueItem` LIMIT 100;
/* 2026-05-13 21:01:42 [203 ms] */ 
SELECT estoqueItem, COUNT (`estoqueItem`)
FROM ItensEstoque
GROUP BY estoqueItem LIMIT 100;
/* 2026-05-13 21:01:55 [215 ms] */ 
SELECT estoqueItem, SUM (estoqueItem)
FROM ItensEstoque
GROUP BY estoqueItem LIMIT 100;
/* 2026-05-13 21:02:02 [201 ms] */ 
SELECT estoqueItem, MAX (estoqueItem)
FROM ItensEstoque
GROUP BY estoqueItem LIMIT 100;
/* 2026-05-13 21:02:15 [204 ms] */ 
SELECT estoqueItem, COUNT (*)
FROM ItensEstoque
GROUP BY estoqueItem LIMIT 100;
/* 2026-05-13 21:02:40 [202 ms] */ 
SELECT estoqueItem, COUNT (setorItem) as QTD
FROM ItensEstoque
GROUP BY estoqueItem LIMIT 100;
/* 2026-05-13 21:03:22 [203 ms] */ 
SELECT setorItem, COUNT (*) as QTD
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 21:05:36 [217 ms] */ 
SELECT ROUND (2,setorItem), AVG (precoVendaItem) as MD
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 21:08:50 [200 ms] */ 
SELECT setorItem, MIN (precoVendaItem) as min ,MAX (precoVendaItem) as max
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 21:20:35 [1903 ms] */ 
SELECT setorItem, COUNT (*) as QTD
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 21:20:44 [395 ms] */ 
SELECT setorItem, AVG (precoVendaItem) as MD
FROM ItensEstoque
GROUP BY setorItem LIMIT 100;
