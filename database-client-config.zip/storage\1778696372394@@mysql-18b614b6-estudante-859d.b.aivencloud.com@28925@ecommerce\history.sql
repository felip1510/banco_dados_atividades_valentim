/* 2026-05-13 17:01:33 [203 ms] */ 
DELETE FROM `produto` WHERE `id` IN (14,13,12,11,10,9,8,7,6,5,4,3,2,1);
/* 2026-05-13 17:01:46 [202 ms] */ 
DELETE FROM `produto` WHERE `id` IN (15,16,17,18,19,20,21,22,23,24,25,26,27,28);
/* 2026-05-13 17:09:22 [208 ms] */ 
UPDATE produto
SET
    nome = 'pc usado - notebook',
    descricao = 'Notebook com SSD e 16GB de RAM',
    estoque = 15,
    categoria_id = 1
WHERE id=4;
/* 2026-05-13 17:09:31 [207 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 17:09:47 [207 ms] */ 
UPDATE produto
SET
    nome = 'pc usado - notebook',
    descricao = 'Notebook com SSD e 16GB de RAM',
    estoque = 15,
    categoria_id = 1
WHERE id=35;
/* 2026-05-13 17:09:49 [206 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:17:43 [544 ms] */ 
DELETE FROM produto WHERE id =33;
/* 2026-05-13 18:17:46 [203 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:21:10 [269 ms] */ 
INSERT INTO produto() 
VALUES(DEFAULT, 'telefoneX','telefone legal',50.00,120,1);
/* 2026-05-13 18:21:13 [203 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:28:59 [697 ms] */ 
DELETE FROM produto
WHERE nome = 'Clean Code'AND id=36;
/* 2026-05-13 18:29:03 [204 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:30:20 [663 ms] */ 
DELETE FROM produto
WHERE nome = 'Clean Code' or id=31;
/* 2026-05-13 18:30:26 [202 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 18:36:30 [2166 ms] */ 
CREATE DATABASE estoquecomercial;
