/* 2026-05-13 16:10:38 [1184 ms] */ 
CREATE DATABASE ecommerce;
/* 2026-05-13 16:11:16 [404 ms] */ 
USE ecommerce;
/* 2026-05-13 16:11:23 [873 ms] */ 
CREATE TABLE categoria (
    id INT AUTO_INCREMENT,
    nome VARCHAR(100),
    descricao TEXT,
    PRIMARY KEY (id)
);
/* 2026-05-13 16:12:09 [222 ms] */ 
CREATE TABLE produto (
    id INT AUTO_INCREMENT,
    nome VARCHAR(150),
    descricao TEXT,
    preco DECIMAL(10,2),
    estoque INT,
    categoria_id INT,
    PRIMARY KEY (id),
    FOREIGN KEY (categoria_id) REFERENCES categoria(id)
);
/* 2026-05-13 16:15:09 [238 ms] */ 
INSERT INTO categoria (nome, descricao) VALUES
('Eletrônicos', 'Produtos eletrônicos e acessórios'),
('Roupas', 'Vestuário masculino e feminino'),
('Livros', 'Livros de diversos gêneros'),
('Casa e Decoração', 'Itens para casa e decoração'),
('Esportes', 'Artigos esportivos e acessórios');
/* 2026-05-13 16:15:12 [210 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES
('Smartphone Galaxy S23', 'Smartphone Samsung com 256GB', 3999.90, 15, 1),
('Notebook Dell Inspiron', 'Notebook Dell i7 16GB RAM', 5299.00, 8, 1),
('Fone Bluetooth JBL', 'Fone sem fio com cancelamento de ruído', 499.90, 30, 1),

('Camiseta Básica', 'Camiseta de algodão unissex', 59.90, 50, 2),
('Calça Jeans Slim', 'Calça jeans masculina slim fit', 129.90, 25, 2),
('Jaqueta Feminina', 'Jaqueta feminina impermeável', 249.90, 12, 2),

('Dom Casmurro', 'Livro clássico de Machado de Assis', 39.90, 20, 3),
('Clean Code', 'Livro sobre boas práticas de programação', 89.90, 10, 3),
('O Senhor dos Anéis', 'Trilogia de fantasia épica', 119.90, 7, 3),

('Luminária LED', 'Luminária moderna para escritório', 79.90, 18, 4),
('Tapete Decorativo', 'Tapete para sala 2x3m', 199.90, 6, 4),

('Bola de Futebol', 'Bola oficial tamanho 5', 99.90, 14, 5),
('Tênis de Corrida', 'Tênis esportivo leve e confortável', 299.90, 9, 5),
('Garrafa Térmica', 'Garrafa térmica inox 1L', 69.90, 22, 5);
/* 2026-05-13 16:39:20 [213 ms] */ 
USE ecommerce;
/* 2026-05-13 16:39:57 [205 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 16:41:11 [233 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE ID = 2;
/* 2026-05-13 16:42:13 [222 ms] */ 
UPDATE produto
SET categoria_id=3
-- WHERE ID = 2;
/* 2026-05-13 16:51:36 [3025 ms] */ 
USE ecommerce;
/* 2026-05-13 16:51:41 [203 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE ID = 3;
/* 2026-05-13 16:51:43 [203 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE ID = 2;
/* 2026-05-13 16:51:50 [209 ms] */ 
UPDATE produto
SET categoria_id=4
WHERE ID = 3;
/* 2026-05-13 16:51:55 [203 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE ID = 4;
/* 2026-05-13 16:52:02 [202 ms] */ 
UPDATE produto
SET categoria_id=1
WHERE ID = 5;
/* 2026-05-13 16:53:20 [203 ms] */ 
USE ecommerce;
/* 2026-05-13 16:53:30 [638 ms] */ 
UPDATE produto
SET categoria_id=1
WHERE ID = 1;
/* 2026-05-13 16:53:38 [864 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE ID = 2;
/* 2026-05-13 16:53:47 [204 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE ID = 3;
/* 2026-05-13 16:53:52 [633 ms] */ 
UPDATE produto
SET categoria_id=4
WHERE ID = 3;
/* 2026-05-13 16:53:58 [202 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE ID = 4;
/* 2026-05-13 16:55:32 [204 ms] */ 
USE ecommerce;
/* 2026-05-13 16:55:35 [202 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'M%';
/* 2026-05-13 16:56:46 [203 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 16:56:50 [203 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'S%';
/* 2026-05-13 16:56:56 [204 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:57:08 [204 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'B%';
/* 2026-05-13 16:57:10 [203 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:57:33 [650 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE nome LIKE'%';
/* 2026-05-13 16:57:36 [653 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:57:46 [203 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE nome LIKE'B%';
/* 2026-05-13 16:57:50 [648 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE ID = 2;
/* 2026-05-13 16:58:11 [203 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE id = 3;
/* 2026-05-13 16:58:28 [202 ms] */ 
USE ecommerce;
/* 2026-05-13 16:58:31 [203 ms] */ 
UPDATE produto
SET categoria_id=4
WHERE id = 4;
/* 2026-05-13 16:58:36 [204 ms] */ 
UPDATE produto
SET categoria_id=1
WHERE id = 4;
/* 2026-05-13 16:58:41 [203 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE id = 1;
/* 2026-05-13 16:58:44 [203 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:58:55 [1104 ms] */ 
UPDATE produto
SET categoria_id=4
WHERE id = 2;
/* 2026-05-13 17:00:11 [934 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE preco >=500;
/* 2026-05-13 17:00:23 [202 ms] */ 
USE ecommerce;
/* 2026-05-13 17:01:05 [204 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES
('Smartphone Galaxy S23', 'Smartphone Samsung com 256GB', 3999.90, 15, 1),
('Notebook Dell Inspiron', 'Notebook Dell i7 16GB RAM', 5299.00, 8, 1),
('Fone Bluetooth JBL', 'Fone sem fio com cancelamento de ruído', 499.90, 30, 1),

('Camiseta Básica', 'Camiseta de algodão unissex', 59.90, 50, 2),
('Calça Jeans Slim', 'Calça jeans masculina slim fit', 129.90, 25, 2),
('Jaqueta Feminina', 'Jaqueta feminina impermeável', 249.90, 12, 2),

('Dom Casmurro', 'Livro clássico de Machado de Assis', 39.90, 20, 3),
('Clean Code', 'Livro sobre boas práticas de programação', 89.90, 10, 3),
('O Senhor dos Anéis', 'Trilogia de fantasia épica', 119.90, 7, 3),

('Luminária LED', 'Luminária moderna para escritório', 79.90, 18, 4),
('Tapete Decorativo', 'Tapete para sala 2x3m', 199.90, 6, 4),

('Bola de Futebol', 'Bola oficial tamanho 5', 99.90, 14, 5),
('Tênis de Corrida', 'Tênis esportivo leve e confortável', 299.90, 9, 5),
('Garrafa Térmica', 'Garrafa térmica inox 1L', 69.90, 22, 5);
/* 2026-05-13 17:01:57 [202 ms] */ 
USE ecommerce;
/* 2026-05-13 17:02:01 [642 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES
('Smartphone Galaxy S23', 'Smartphone Samsung com 256GB', 3999.90, 15, 1),
('Notebook Dell Inspiron', 'Notebook Dell i7 16GB RAM', 5299.00, 8, 1),
('Fone Bluetooth JBL', 'Fone sem fio com cancelamento de ruído', 499.90, 30, 1),

('Camiseta Básica', 'Camiseta de algodão unissex', 59.90, 50, 2),
('Calça Jeans Slim', 'Calça jeans masculina slim fit', 129.90, 25, 2),
('Jaqueta Feminina', 'Jaqueta feminina impermeável', 249.90, 12, 2),

('Dom Casmurro', 'Livro clássico de Machado de Assis', 39.90, 20, 3),
('Clean Code', 'Livro sobre boas práticas de programação', 89.90, 10, 3),
('O Senhor dos Anéis', 'Trilogia de fantasia épica', 119.90, 7, 3),

('Luminária LED', 'Luminária moderna para escritório', 79.90, 18, 4),
('Tapete Decorativo', 'Tapete para sala 2x3m', 199.90, 6, 4),

('Bola de Futebol', 'Bola oficial tamanho 5', 99.90, 14, 5),
('Tênis de Corrida', 'Tênis esportivo leve e confortável', 299.90, 9, 5),
('Garrafa Térmica', 'Garrafa térmica inox 1L', 69.90, 22, 5);
/* 2026-05-13 17:02:21 [640 ms] */ 
USE ecommerce;
/* 2026-05-13 17:02:23 [203 ms] */ 
UPDATE produto
SET categoria_id=5
WHERE preco >=500;
/* 2026-05-13 17:02:56 [203 ms] */ 
UPDATE produto
SET categoria_id = 30
WHERE id = 1;
/* 2026-05-13 17:03:48 [204 ms] */ 
UPDATE produto
SET categoria_id = 20
WHERE id = 1;
/* 2026-05-13 17:04:04 [846 ms] */ 
USE ecommerce;
