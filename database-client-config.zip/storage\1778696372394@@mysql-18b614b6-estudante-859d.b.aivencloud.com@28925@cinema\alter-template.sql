ALTER TABLE `categoria` 
	CHANGE `descricao_categoria` `descricao_categoria` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL ;