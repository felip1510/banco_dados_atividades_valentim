ALTER TABLE ``ItensEstoque`` 
	CHANGE ``estoqueItem`` ``estoqueItem`` int DEFAULT NULL ;